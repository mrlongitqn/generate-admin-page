﻿using System;
using BK.Util;

namespace ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            ///////////////////////////////////////////////////////////////
            /// Creation and Initialization of the Collection class     ///
            ///////////////////////////////////////////////////////////////
            MultimapBK<string, string> multiMapCollection = new MultimapBK<string, string>();

            multiMapCollection.Add("Alice", "Home: 333-222-9999");
            multiMapCollection.Add("Alice", "Office: 222-211-9999");
            multiMapCollection.Add("Bob", "Home: 111-112-9999");
            multiMapCollection.Add("Bob", "Office: 121-112-9999");
            multiMapCollection.Add("Bob", "Office: 122-112-9999");

            // Search for Key - Bob
            string SearchKey = "Alice";

            // Get the First Item
            string ValueRet = multiMapCollection.GetFirstItem(SearchKey);

            while (ValueRet != null)
            {
                string SearchKey1 = "Bob";
                // Print the Item to console.
                System.Console.WriteLine("Key = {0}; Value = {1}", SearchKey1, ValueRet);
                // Get next Item
                ValueRet = multiMapCollection.GetNextItem(SearchKey1);
            }
        }
    }
}
