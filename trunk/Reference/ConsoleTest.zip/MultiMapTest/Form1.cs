﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BK.Util;

namespace MultiMapTest
{
    public partial class Form1 : Form
    {
        private MultimapBK<string, string> multiMap;

        MultimapBK<string, string>.MultimapEnum enumMultimap;

        public Form1()
        {
            InitializeComponent();
            multiMap = new MultimapBK<string, string>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "Hello";
            richTextBox2.AppendText("Just Click Go button to begin");
            richTextBox1.AppendText("This is a limited dictionary to demonstrate C# Generic Multi Map Collection.  Just Search for: Hello, Happy or World");
            
            multiMap.Add("hello", "used to express a greeting, answer a telephone, or attract attention.");
            multiMap.Add("hello", "an exclamation of surprise, wonder, elation, etc");
            multiMap.Add("hello", "used derisively to question the comprehension, intelligence, or common sense of the person being addressed");

            multiMap.Add("happy", "delighted, pleased, or glad, as over a particular thing: to be happy to see a person. ");
            multiMap.Add("happy", "characterized by or indicative of pleasure, contentment, or joy: a happy mood; a happy frame of mind.");
            multiMap.Add("happy", "favored by fortune; fortunate or lucky: a happy, fruitful land. ");
            multiMap.Add("happy", "apt or felicitous, as actions, utterances, or ideas.");
            multiMap.Add("happy", "obsessed by or quick to use the item indicated (usually used in combination): a trigger-happy gangster. Everybody is gadget-happy these days. ");

            multiMap.Add("world", "the earth or globe, considered as a planet.");
            multiMap.Add("world", "a particular division of the earth.");
            multiMap.Add("world", "the earth or a part of it, with its inhabitants, affairs, etc., during a particular period: the ancient world.");
            multiMap.Add("world", "the public generally: The whole world knows it");
            multiMap.Add("world", "the class of persons devoted to the affairs, interests, or pursuits of this life: The world worships success. ");
            multiMap.Add("world", "everything that exists; the universe; the macrocosm.");
            multiMap.Add("world", "any indefinitely great expanse.");
            multiMap.Add("world", "any heavenly body;");

            enumMultimap = multiMap.GetEnumerator();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox2.Clear();

            string ItemToDisplay = multiMap.GetFirstItem(textBox1.Text.ToLower());

            if (null != ItemToDisplay)
            {

                richTextBox2.AppendText(ItemToDisplay);
            }
            else
            {
                richTextBox2.AppendText("No Item matches this search");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox2.Clear();
            string retVal = multiMap.Iterate(textBox1.Text.ToLower());

            if (retVal != null)
            {
                richTextBox2.AppendText(retVal);
            }
            else
            {
                richTextBox2.AppendText("No more meaning found in Dictionary");
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            multiMap.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox2.Clear();
            textBox1.Clear();
            
            if (enumMultimap.MoveNext())
            {
                textBox1.Text = enumMultimap.Current.Key;

                while (enumMultimap.Current.Value.MoveNext())
                {
                    richTextBox2.AppendText(enumMultimap.Current.Value.Current);
                    richTextBox2.AppendText(":\n");
                }

                //string MeaningToPrint = enumMultimap.Current.Value.Next;
                //while (MeaningToPrint != null)
                //{
                //    richTextBox2.AppendText(MeaningToPrint);
                //    richTextBox2.AppendText(":\n");
                //    MeaningToPrint = enumMultimap.Current.Value.Next;
                //}
            }
            else
            {
                richTextBox2.AppendText("No More Entry in Dictionary. Resetting to start from begining");
                enumMultimap.Reset();
            }
        }
    }
}
